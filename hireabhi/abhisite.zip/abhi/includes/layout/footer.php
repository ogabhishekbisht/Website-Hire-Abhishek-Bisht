<div id = "footer"> Copyright 2018 Abhishek Bisht</div>
</BODY>
</HTML>
<?php 
if(isset($connection))
{
mysqli_close($connection);
}
?>